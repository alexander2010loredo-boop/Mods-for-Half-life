import numpy as np, struct, os, sys, math, pickle
from PIL import Image
sys.setrecursionlimit(100000)

BS = 40
OUT = '/home/claude/bmluna'
(AIR, SAND, ROCK, LABW, LABF, METAL, HAZARD, CONCRETE, CRATE, ROCKW, ROCKO, GLASS,
 PANEL, STFLOOR, STLIGHT, MOON, MOONROCK, DOMEW, SKY) = range(19)

FACE_TEX = {
    SAND: ('sand',) * 3, ROCK: ('rock',) * 3, LABW: ('labw',) * 3, LABF: ('labf',) * 3, METAL: ('metal',) * 3,
    HAZARD: ('hazard',) * 3, CONCRETE: ('concrete',) * 3, CRATE: ('crate',) * 3, ROCKW: ('rocketw',) * 3,
    ROCKO: ('rocketo',) * 3, GLASS: ('rocketg',) * 3, PANEL: ('stpanel',) * 3, STFLOOR: ('stfloor',) * 3,
    STLIGHT: ('stlight',) * 3, MOON: ('moon',) * 3, MOONROCK: ('moonrock',) * 3, DOMEW: ('domew',) * 3,
    SKY: ('sky',) * 3,
}
BRIGHT = {STLIGHT: 1.5, GLASS: 1.1, ROCKO: 1.0}
SHADE = {(2, 1): 176, (0, 1): 150, (0, -1): 150, (1, 1): 128, (1, -1): 128, (2, -1): 96}

# ------------------------------------------------------------------ texturas
def clipc(a): return np.clip(a, 0, 255).astype(np.uint8)
def noise(base, var, seed, n=16):
    r = np.random.default_rng(seed)
    return np.array(base, dtype=int)[None, None, :] + r.integers(-var, var + 1, (n, n, 1))

def make_textures():
    T = {}
    r = np.random.default_rng(42)
    a = noise((214, 184, 126), 10, 1)
    for _ in range(14): a[r.integers(0, 16), r.integers(0, 16)] = (186, 156, 102)
    T['sand'] = clipc(a)
    a = noise((140, 92, 64), 12, 2)
    for _ in range(3):
        x, y = int(r.integers(0, 16)), int(r.integers(0, 16))
        for n in range(int(r.integers(4, 9))): a[(y + n) % 16, (x + n // 2) % 16] = (84, 52, 36)
    T['rock'] = clipc(a)
    a = noise((205, 210, 218), 4, 3)
    a[:, 0] = a[0, :] = (150, 156, 168); a[:, 8] = (172, 178, 190)
    a[6:8, :] = (60, 110, 190)
    for (y, x) in ((2, 2), (2, 13), (13, 2), (13, 13)): a[y, x] = (90, 94, 104)
    T['labw'] = clipc(a)
    a = noise((110, 116, 126), 5, 4); a[:, ::8] = (80, 84, 94); a[::8, :] = (80, 84, 94)
    T['labf'] = clipc(a)
    a = noise((72, 78, 88), 6, 5); a[8, :] = (46, 50, 58)
    for (y, x) in ((2, 2), (2, 13), (13, 2), (13, 13)): a[y, x] = (140, 146, 158)
    T['metal'] = clipc(a)
    a = np.zeros((16, 16, 3), dtype=int)
    for y in range(16):
        for x in range(16): a[y, x] = (235, 200, 30) if ((x + y) // 4) % 2 == 0 else (30, 30, 30)
    T['hazard'] = clipc(a)
    T['concrete'] = clipc(noise((150, 148, 142), 8, 6))
    a = noise((156, 112, 64), 6, 7)
    a[0, :] = a[15, :] = a[:, 0] = a[:, 15] = (96, 64, 34)
    for n in range(16): a[n, n] = a[n, 15 - n] = (110, 76, 42)
    T['crate'] = clipc(a)
    a = noise((236, 236, 242), 3, 8); a[0, :] = a[:, 0] = (170, 174, 186); T['rocketw'] = clipc(a)
    a = noise((232, 106, 36), 6, 9); a[0, :] = a[:, 0] = (170, 70, 20); T['rocketo'] = clipc(a)
    a = noise((30, 50, 100), 4, 10); a[1:4, 1:4] = (110, 160, 230); a[0, :] = a[15, :] = a[:, 0] = a[:, 15] = (170, 174, 186)
    T['rocketg'] = clipc(a)
    a = noise((84, 96, 116), 5, 11); a[0, :] = a[:, 0] = (56, 64, 80); a[3, 3] = a[12, 12] = (160, 210, 255)
    T['stpanel'] = clipc(a)
    a = noise((56, 60, 66), 5, 12); a[::2, :] = (36, 38, 42); T['stfloor'] = clipc(a)
    a = noise((225, 240, 255), 4, 13); a[0, :] = a[15, :] = a[:, 0] = a[:, 15] = (150, 180, 210); T['stlight'] = clipc(a)
    a = noise((156, 156, 158), 10, 14)
    for _ in range(16): a[r.integers(0, 16), r.integers(0, 16)] = (110, 110, 114)
    for _ in range(8): a[r.integers(0, 16), r.integers(0, 16)] = (190, 190, 192)
    T['moon'] = clipc(a)
    a = noise((108, 108, 116), 12, 15)
    for _ in range(3):
        x, y = int(r.integers(0, 16)), int(r.integers(0, 16))
        for n in range(int(r.integers(4, 9))): a[(y + n) % 16, (x + n // 2) % 16] = (62, 62, 70)
    T['moonrock'] = clipc(a)
    a = noise((222, 226, 234), 3, 16); a[::4, :] = (172, 182, 198); a[:, ::8] = (172, 182, 198)
    T['domew'] = clipc(a)
    a = noise((118, 124, 134), 4, 17)
    for y in range(3):
        for x in range(16): a[y, x] = (235, 200, 30) if ((x + y) // 3) % 2 == 0 else (30, 30, 30)
    a[:, 7:9] = (80, 84, 94); T['door'] = clipc(a)
    a = noise((180, 40, 40), 4, 18); a[5:11, 5:11] = (255, 210, 120); T['button'] = clipc(a)
    T['aaatrigger'] = clipc(noise((230, 120, 20), 4, 19))
    s = np.zeros((128, 256, 3), dtype=np.uint8)
    for y in range(128): s[y, :] = (10, 12, 30 + y // 2)
    T['sky'] = s
    return T

def miptex(name, rgb):
    h, w = rgb.shape[:2]
    img = Image.fromarray(rgb, 'RGB')
    base = img.quantize(colors=256, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
    pal = list(base.getpalette()[:768]); pal += [0] * (768 - len(pal))
    mips = [np.array(base).astype(np.uint8).tobytes()]
    for m in (1, 2, 3):
        im = img.resize((w >> m, h >> m), Image.BOX).quantize(palette=base, dither=Image.Dither.NONE)
        mips.append(np.array(im).astype(np.uint8).tobytes())
    offs = [40]
    for m in mips[:3]: offs.append(offs[-1] + len(m))
    data = name.encode().ljust(16, b'\0') + struct.pack('<II4I', w, h, *offs)
    data += b''.join(mips) + struct.pack('<H', 256) + bytes(pal)
    while len(data) % 4: data += b'\0'
    return data

TEXTURES = make_textures()

# ------------------------------------------------------------------ utilidades de mapa
class Spec:
    def __init__(s, name, NX, NY, NZ, sky, tint):
        s.name, s.NX, s.NY, s.NZ, s.sky, s.tint = name, NX, NY, NZ, sky, tint
        s.mat = np.zeros((NX, NY, NZ), dtype=np.uint8)
        s.boxes = []; s.ents = []
        s.LX = (np.arange(NX + 1) - NX / 2) * BS; s.LY = (np.arange(NY + 1) - NY / 2) * BS
        s.LZ = np.arange(NZ + 1) * BS * 1.0
    def fill(s, m, x0, x1, y0, y1, z0, z1): s.mat[x0:x1, y0:y1, z0:z1] = m
    def box_cells(s, x0, x1, y0, y1, z0, z1, tex):
        """caja de modelo = celdas [x0,x1)x[y0,y1)x[z0,z1); devuelve '*N'"""
        s.boxes.append(dict(mins=(s.LX[x0], s.LY[y0], s.LZ[z0]), maxs=(s.LX[x1], s.LY[y1], s.LZ[z1]), tex=tex))
        return '*%d' % len(s.boxes)
    def box_abs(s, mins, maxs, tex):
        s.boxes.append(dict(mins=tuple(float(v) for v in mins), maxs=tuple(float(v) for v in maxs), tex=tex))
        return '*%d' % len(s.boxes)
    def ent(s, cls, **kw): s.ents.append(dict(classname=cls, **kw))
    def floor_k(s, i, j):
        for k in range(s.NZ):
            if s.mat[i, j, k] == AIR: return k
        return 0
    def at(s, i, j, dz, k=None):
        if k is None: k = s.floor_k(i, j)
        return '%g %g %g' % (s.LX[i] + BS / 2, s.LY[j] + BS / 2, k * BS + dz)
    def thing(s, cls, i, j, dz=16, k=None, **kw): s.ent(cls, origin=s.at(i, j, dz, k), **kw)
    def mon(s, cls, i, j, ang=0, k=None, **kw): s.ent(cls, origin=s.at(i, j, 40, k), angles='0 %d 0' % ang, **kw)
    def sky_borders(s):
        m = s.mat
        m[0, :, :] = m[-1, :, :] = SKY; m[:, 0, :] = m[:, -1, :] = SKY; m[:, :, -1] = SKY

def prefix(S):
    P = np.zeros((S.shape[0] + 1, S.shape[1] + 1, S.shape[2] + 1), dtype=np.int64)
    P[1:, 1:, 1:] = S.astype(np.int64).cumsum(0).cumsum(1).cumsum(2)
    return P
def rsum(P, r):
    x0, x1, y0, y1, z0, z1 = r
    return (P[x1, y1, z1] - P[x0, y1, z1] - P[x1, y0, z1] - P[x1, y1, z0]
            + P[x0, y0, z1] + P[x0, y1, z0] + P[x1, y0, z0] - P[x0, y0, z0])
def choose(S, r):
    x0, x1, y0, y1, z0, z1 = r
    sub = S[x0:x1, y0:y1, z0:z1]; shp = sub.shape; cands = []
    for ax in range(3):
        oth = tuple(a for a in range(3) if a != ax)
        n = shp[ax]; area = shp[oth[0]] * shp[oth[1]]
        sol = np.flatnonzero(sub.any(axis=oth)); emp = np.flatnonzero((~sub).any(axis=oth))
        s0, s1 = sol[0], sol[-1]; e0, e1 = emp[0], emp[-1]
        if s0 > 0: cands.append((s0 * area, ax, int(s0)))
        if s1 < n - 1: cands.append(((n - 1 - s1) * area, ax, int(s1 + 1)))
        if e0 > 0: cands.append((e0 * area, ax, int(e0)))
        if e1 < n - 1: cands.append(((n - 1 - e1) * area, ax, int(e1 + 1)))
    if cands:
        _, ax, p = max(cands); return ax, p
    ax = int(np.argmax(shp)); return ax, shp[ax] // 2
def split_region(r, ax, p):
    lo = list(r); hi = list(r); X = r[2 * ax] + p
    lo[2 * ax + 1] = X; hi[2 * ax] = X
    return tuple(lo), tuple(hi), X

HULLS = {1: ((-16, -16, -36), (16, 16, 36)), 2: ((-32, -32, -32), (32, 32, 32)), 3: ((-16, -16, -18), (16, 16, 18))}

def build(sp):
    mat = sp.mat; S = mat != AIR; NX, NY, NZ = S.shape
    LINES = [sp.LX, sp.LY, sp.LZ]; LX, LY, LZ = LINES
    planes = []; plane_idx = {}
    def plane(axis, dist):
        key = (axis, float(dist))
        if key not in plane_idx:
            n = [0.0, 0.0, 0.0]; n[axis] = 1.0
            plane_idx[key] = len(planes); planes.append((n, float(dist), axis))
        return plane_idx[key]
    nodes = []; leaves = [dict(contents=-2, mins=(0, 0, 0), maxs=(0, 0, 0))]
    faces = []; leafid = np.zeros(S.shape, dtype=np.int32); Pv = prefix(S)

    def region_world(r):
        x0, x1, y0, y1, z0, z1 = r
        return (LX[x0], LY[y0], LZ[z0]), (LX[x1], LY[y1], LZ[z1])

    def make_faces(r, ax, X):
        b, c = (ax + 1) % 3, (ax + 2) % 3
        rem = [a for a in range(3) if a != ax]
        lo = [r[0], r[2], r[4]]; hi = [r[1], r[3], r[5]]
        sa = [slice(None)] * 3; sb = [slice(None)] * 3
        for a in rem: sa[a] = sb[a] = slice(lo[a], hi[a])
        sa[ax] = X - 1; sb[ax] = X
        A = S[tuple(sa)]; B = S[tuple(sb)]; out = []
        for i0, i1 in np.argwhere(A != B):
            idx = [0, 0, 0]; idx[rem[0]] = lo[rem[0]] + int(i0); idx[rem[1]] = lo[rem[1]] + int(i1)
            ia = list(idx); ib = list(idx); ia[ax] = X - 1; ib[ax] = X
            if S[tuple(ia)]: sg = 1; sc = tuple(ia); ec = tuple(ib)
            else: sg = -1; sc = tuple(ib); ec = tuple(ia)
            m = int(mat[sc]); top, side, bot = FACE_TEX[m]
            tex = top if (ax == 2 and sg > 0) else (bot if ax == 2 else side)
            d = LINES[ax][X]
            b0, b1 = LINES[b][idx[b]], LINES[b][idx[b] + 1]
            c0, c1 = LINES[c][idx[c]], LINES[c][idx[c] + 1]
            quad = [(b0, c0), (b1, c0), (b1, c1), (b0, c1)]
            if sg > 0: quad = quad[::-1]
            pts = []
            for (u, v) in quad:
                p = [0.0, 0.0, 0.0]; p[ax] = d; p[b] = u; p[c] = v; pts.append(tuple(p))
            out.append(dict(plane=plane(ax, d), side=0 if sg > 0 else 1, pts=pts, tex=tex, axis=ax, sign=sg,
                            empty=ec, shade=SHADE[(ax, sg)] * BRIGHT.get(m, 1.0)))
        return out

    def vbuild(r):
        tot = (r[1] - r[0]) * (r[3] - r[2]) * (r[5] - r[4]); cnt = rsum(Pv, r)
        if cnt == tot: return -1
        if cnt == 0:
            li = len(leaves); mn, mx = region_world(r)
            leaves.append(dict(contents=-1, mins=mn, maxs=mx))
            leafid[r[0]:r[1], r[2]:r[3], r[4]:r[5]] = li
            return -(li + 1)
        ax, p = choose(S, r); lo_r, hi_r, X = split_region(r, ax, p)
        idx = len(nodes); nodes.append(None); first = len(faces)
        faces.extend(make_faces(r, ax, X)); nf = len(faces) - first
        front = vbuild(hi_r); back = vbuild(lo_r); mn, mx = region_world(r)
        nodes[idx] = dict(plane=plane(ax, LINES[ax][X]), children=(front, back), mins=mn, maxs=mx, first=first, num=nf)
        return idx
    assert vbuild((0, NX, 0, NY, 0, NZ)) == 0
    world_leaves = len(leaves) - 1
    nworld_faces = len(faces)

    # ---- hulls de colision del mundo
    ORIGIN = [LX[0], LY[0], LZ[0]]; VP = prefix(S); cnodes = []; chull_root = {}
    def hull_grid(hmin, hmax):
        lines = []; los = []; his = []
        for ax in range(3):
            N = S.shape[ax]
            L = np.unique(np.concatenate([ORIGIN[ax] + BS * np.arange(N + 1) - hmax[ax], ORIGIN[ax] + BS * np.arange(N + 1) - hmin[ax]]))
            lines.append(L); c = (L[:-1] + L[1:]) / 2.0; u = (c - ORIGIN[ax]) / BS
            lo = np.floor(u + hmin[ax] / BS - 1 + 1e-9).astype(int) + 1
            hi = np.ceil(u + hmax[ax] / BS - 1e-9).astype(int) - 1
            lo = np.clip(lo, 0, N); hi1 = np.clip(hi + 1, 0, N); hi1 = np.maximum(hi1, lo)
            los.append(lo); his.append(hi1)
        g = lambda ix, iy, iz: VP[np.ix_(ix, iy, iz)]
        lo, hi = los, his
        cnt = (g(hi[0], hi[1], hi[2]) - g(lo[0], hi[1], hi[2]) - g(hi[0], lo[1], hi[2]) - g(hi[0], hi[1], lo[2])
               + g(lo[0], lo[1], hi[2]) + g(lo[0], hi[1], lo[2]) + g(hi[0], lo[1], lo[2]) - g(lo[0], lo[1], lo[2]))
        return lines, cnt > 0
    def cbuild(Sh, Ph, lines, r):
        tot = (r[1] - r[0]) * (r[3] - r[2]) * (r[5] - r[4]); cnt = rsum(Ph, r)
        if cnt == tot: return -2
        if cnt == 0: return -1
        ax, p = choose(Sh, r); lo_r, hi_r, X = split_region(r, ax, p)
        idx = len(cnodes); cnodes.append(None)
        front = cbuild(Sh, Ph, lines, hi_r); back = cbuild(Sh, Ph, lines, lo_r)
        cnodes[idx] = (plane(ax, lines[ax][X]), front, back); return idx
    for h, (hmin, hmax) in HULLS.items():
        lines, Sh = hull_grid(hmin, hmax); Ph = prefix(Sh)
        chull_root[h] = cbuild(Sh, Ph, lines, (0, Sh.shape[0], 0, Sh.shape[1], 0, Sh.shape[2]))

    # ---- submodelos (cajas)
    empty_leaf = len(leaves); leaves.append(dict(contents=-1, mins=(0, 0, 0), maxs=(0, 0, 0)))
    models = [dict(mins=(LX[0], LY[0], LZ[0]), maxs=(LX[-1], LY[-1], LZ[-1]), head=[0, chull_root[1], chull_root[2], chull_root[3]],
                   visleafs=world_leaves, firstface=0, numfaces=nworld_faces)]
    for bx in sp.boxes:
        mn, mx = bx['mins'], bx['maxs']
        order = [(0, mx[0], 1), (0, mn[0], -1), (1, mx[1], 1), (1, mn[1], -1), (2, mx[2], 1), (2, mn[2], -1)]
        n0 = len(nodes); f0 = len(faces)
        for q, (ax, d, sg) in enumerate(order):
            b, c = (ax + 1) % 3, (ax + 2) % 3
            quad = [(mn[b], mn[c]), (mx[b], mn[c]), (mx[b], mx[c]), (mn[b], mx[c])]
            if sg > 0: quad = quad[::-1]
            pts = []
            for (u, v) in quad:
                p = [0.0, 0.0, 0.0]; p[ax] = d; p[b] = u; p[c] = v; pts.append(tuple(p))
            faces.append(dict(plane=plane(ax, d), side=0 if sg > 0 else 1, pts=pts, tex=bx['tex'], axis=ax, sign=sg,
                              empty=None, shade=SHADE[(ax, sg)]))
            outside = -(empty_leaf + 1); inside_solid = -1
            if sg > 0: ch = (outside, n0 + q + 1 if q < 5 else inside_solid)
            else: ch = (n0 + q + 1 if q < 5 else inside_solid, outside)
            if q == 5: ch = (inside_solid, outside)
            nodes.append(dict(plane=plane(ax, d), children=ch, mins=mn, maxs=mx, first=f0 + q, num=1))
        heads = [n0]
        for h, (hmin, hmax) in HULLS.items():
            emn = [mn[a] - hmax[a] for a in range(3)]; emx = [mx[a] - hmin[a] for a in range(3)]
            base = len(cnodes)
            seq = [(0, emx[0], 1), (0, emn[0], -1), (1, emx[1], 1), (1, emn[1], -1), (2, emx[2], 1), (2, emn[2], -1)]
            for q, (ax, d, sg) in enumerate(seq):
                nxt = base + q + 1 if q < 5 else -2
                if sg > 0: ch = (-1, nxt)
                else: ch = (nxt, -1)
                if q == 5: ch = (-2, -1)
                cnodes.append((plane(ax, d), ch[0], ch[1]))
            heads.append(base)
        models.append(dict(mins=mn, maxs=mx, head=heads, visleafs=0, firstface=f0, numfaces=6))

    # ---- lighting / geometria
    texnames = ['sky']
    for f in faces:
        if f['tex'] not in texnames: texnames.append(f['tex'])
    tint = sp.tint
    texblob = [miptex(n, TEXTURES[n]) for n in texnames]; tex_index = {n: i for i, n in enumerate(texnames)}
    off = 4 + 4 * len(texblob); offs = []
    for b in texblob: offs.append(off); off += len(b)
    lump_tex = struct.pack('<I', len(texblob)) + struct.pack('<%dI' % len(texblob), *offs) + b''.join(texblob)
    VECS = {0: ((0, .4, 0), (0, 0, -.4)), 1: ((.4, 0, 0), (0, 0, -.4)), 2: ((.4, 0, 0), (0, -.4, 0))}
    texinfo = []; texinfo_idx = {}
    def get_ti(tex, ax):
        k = (tex, ax)
        if k not in texinfo_idx: texinfo_idx[k] = len(texinfo); texinfo.append((VECS[ax], tex_index[tex]))
        return texinfo_idx[k]
    verts = []; edges = [(0, 0)]; surfedges = []; lighting = bytearray(); recs = []
    for f in faces:
        ti = get_ti(f['tex'], f['axis']); fe = len(surfedges); vi = []
        for p in f['pts']: vi.append(len(verts)); verts.append(p)
        for a in range(4): edges.append((vi[a], vi[(a + 1) % 4])); surfedges.append(len(edges) - 1)
        if f['tex'] == 'sky': lofs = -1
        else:
            sv, tv = VECS[f['axis']]
            ss = [sum(p[k] * sv[k] for k in range(3)) for p in f['pts']]; ts = [sum(p[k] * tv[k] for k in range(3)) for p in f['pts']]
            w = int(math.ceil(max(ss) / 16) - math.floor(min(ss) / 16)) + 1; hh = int(math.ceil(max(ts) / 16) - math.floor(min(ts) / 16)) + 1
            assert w <= 17 and hh <= 17, (w, hh)
            lofs = len(lighting)
            lighting += bytes([int(min(255, f['shade'] * tint[k])) for k in range(3)]) * (w * hh)
        recs.append(struct.pack('<Hhihh4Bi', f['plane'], f['side'], fe, 4, ti, 0, 255, 255, 255, lofs))

    per_leaf = {}
    for fi, f in enumerate(faces[:nworld_faces]):
        per_leaf.setdefault(int(leafid[f['empty']]), []).append(fi)
    marks = []; leaf_first = {}
    for li in range(1, len(leaves)):
        leaf_first[li] = (len(marks), len(per_leaf.get(li, []))); marks.extend(per_leaf.get(li, []))
    s16 = lambda v: int(max(-32768, min(32767, round(v))))
    lump_planes = b''.join(struct.pack('<3ffi', n[0], n[1], n[2], d, t) for n, d, t in planes)
    lump_verts = b''.join(struct.pack('<3f', *v) for v in verts)
    lump_nodes = b''.join(struct.pack('<ihhhhhhhhHH', nd['plane'], nd['children'][0], nd['children'][1],
                                      *[s16(v) for v in nd['mins']], *[s16(v) for v in nd['maxs']], nd['first'], nd['num']) for nd in nodes)
    lump_ti = b''.join(struct.pack('<4f4fii', sv[0], sv[1], sv[2], 0.0, tv[0], tv[1], tv[2], 0.0, mi, 0) for (sv, tv), mi in texinfo)
    lump_clip = b''.join(struct.pack('<ihh', p, a, b) for p, a, b in cnodes)
    lump_leaves = b''
    for li, lf in enumerate(leaves):
        fm, nm = leaf_first.get(li, (0, 0))
        lump_leaves += struct.pack('<iihhhhhhHH4B', lf['contents'], -1, *[s16(v) for v in lf['mins']], *[s16(v) for v in lf['maxs']], fm, nm, 0, 0, 0, 0)
    lump_models = b''
    for md in models:
        lump_models += struct.pack('<3f3f3f', *md['mins'], *md['maxs'], 0, 0, 0) + struct.pack('<4i', *md['head']) + struct.pack('<3i', md['visleafs'], md['firstface'], md['numfaces'])
    ent_txt = ''.join('{\n' + ''.join('"%s" "%s"\n' % (k, v) for k, v in e.items()) + '}\n' for e in sp.ents)
    lumps = [ent_txt.encode() + b'\0', lump_planes, lump_tex, lump_verts, b'', lump_nodes, lump_ti, b''.join(recs), bytes(lighting),
             lump_clip, lump_leaves, b''.join(struct.pack('<H', m) for m in marks), b''.join(struct.pack('<HH', a, b) for a, b in edges),
             b''.join(struct.pack('<i', e) for e in surfedges), lump_models]
    pos = 4 + 15 * 8; hdr = struct.pack('<i', 30); body = b''
    for L in lumps:
        hdr += struct.pack('<ii', pos + len(body), len(L)); body += L
        while len(body) % 4: body += b'\0'
    os.makedirs(OUT + '/maps', exist_ok=True)
    open(OUT + '/maps/%s.bsp' % sp.name, 'wb').write(hdr + body)
    assert len(verts) < 65000 and len(nodes) < 32000 and len(cnodes) < 32000 and len(faces) < 65000 and world_leaves < 8000, \
        (len(verts), len(nodes), len(cnodes), len(faces), world_leaves)
    print(sp.name, 'nodes', len(nodes), 'leaves', world_leaves, 'faces', len(faces), 'verts', len(verts), 'clipnodes', len(cnodes),
          'models', len(models), 'bytes', len(hdr + body))
    np.save('/home/claude/%s_S.npy' % sp.name, S)
    pickle.dump(dict(LX=LX, LY=LY, LZ=LZ, boxes=sp.boxes), open('/home/claude/%s_meta.pkl' % sp.name, 'wb'))

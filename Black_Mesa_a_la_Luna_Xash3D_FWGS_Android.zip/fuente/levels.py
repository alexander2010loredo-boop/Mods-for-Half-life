import numpy as np, math
from PIL import Image
from campaign import *

def heightmap(NX, NY, seed, lo, span, res=12):
    r = np.random.default_rng(seed)
    c = r.random((res, res)).astype('float32')
    hm = np.array(Image.fromarray(c, 'F').resize((NX, NY), Image.BICUBIC))
    return (lo + np.round(hm * span)).astype(int)

def text(sp, name, msg, y='0.18', hold='9', color='255 210 90'):
    sp.ent('game_text', targetname=name, message=msg, x='-1', y=y, effect='0', color1=color, color2='255 255 255',
           fadein='1.2', fadeout='1.5', holdtime=hold, channel='1', spawnflags='1')

def intro(sp, msg, delay='2'):
    text(sp, 'intro', msg)
    sp.ent('trigger_auto', target='intro', delay=delay, spawnflags='1')

def level_cfg(grav):
    return 'sv_gravity %d\n' % grav

# =========================================================================== DIA 1
def level1():
    NX = NY = 48; NZ = 24; H0 = 4
    sp = Spec('bm_dia1', NX, NY, NZ, 'bmsky', (1.0, 0.95, 0.85))
    rng = np.random.default_rng(11)
    H = heightmap(NX, NY, 11, 3, 3)
    H[2:32, 2:26] = H0; H[14:44, 22:44] = H0
    m = sp.mat
    for i in range(NX):
        for j in range(NY):
            for k in range(H[i, j]): m[i, j, k] = SAND if k >= H[i, j] - 2 else ROCK
    sp.sky_borders()
    # rocas dispersas fuera de las zonas planas
    for _ in range(14):
        i = int(rng.integers(3, NX - 3)); j = int(rng.integers(3, NY - 3))
        if (2 <= i < 32 and 2 <= j < 26) or (14 <= i < 44 and 22 <= j < 44): continue
        for di in range(-1, 2):
            for dj in range(-1, 2):
                for k in range(H[i + di, j + dj], H[i + di, j + dj] + max(1, 3 - abs(di) - abs(dj))): m[i + di, j + dj, k] = ROCK
    # ---- hangar
    hx0, hx1, hy0, hy1 = 20, 38, 24, 40
    sp.fill(LABW, hx0, hx1, hy0, hy1, H0, H0 + 15)
    sp.fill(AIR, hx0 + 1, hx1 - 1, hy0 + 1, hy1 - 1, H0, H0 + 14)
    sp.fill(LABF, hx0 + 1, hx1 - 1, hy0 + 1, hy1 - 1, H0 - 1, H0)
    sp.fill(AIR, 28, 31, hy0, hy0 + 1, H0, H0 + 4)          # hueco de la puerta
    sp.fill(HAZARD, 27, 28, hy0, hy0 + 1, H0, H0 + 4); sp.fill(HAZARD, 31, 32, hy0, hy0 + 1, H0, H0 + 4)
    sp.fill(HAZARD, 28, 31, hy0, hy0 + 1, H0 + 4, H0 + 5)
    for x in (24, 28, 32): sp.fill(GLASS, x, x + 2, hy1 - 1, hy1, H0 + 9, H0 + 11)
    for (px, py) in ((22, 26), (35, 26), (22, 37), (35, 37)): sp.fill(METAL, px, px + 2, py, py + 2, H0, H0 + 14)
    for (cxx, cyy, s) in ((23, 30, 2), (34, 31, 2), (24, 35, 1), (33, 36, 2), (25, 28, 1), (32, 28, 1), (22, 33, 1)):
        sp.fill(CRATE, cxx, cxx + s, cyy, cyy + s, H0, H0 + s)
    # ---- cohete
    for z in range(11):
        mt = ROCKO if z % 4 == 1 else ROCKW
        sp.fill(mt, 28, 31, 32, 35, H0 + z, H0 + z + 1)
    sp.fill(GLASS, 29, 30, 32, 33, H0 + 6, H0 + 7)
    sp.fill(ROCKW, 29, 30, 33, 34, H0 + 11, H0 + 13)
    for (fx, fy) in ((27, 33), (31, 33), (29, 31), (29, 35)): sp.fill(ROCKO, fx, fx + 1, fy, fy + 1, H0, H0 + 4)
    # ---- anexo con el boton
    sp.fill(CONCRETE, 12, 19, 14, 21, H0, H0 + 5)
    sp.fill(AIR, 13, 18, 15, 20, H0, H0 + 4)
    sp.fill(AIR, 15, 17, 14, 15, H0, H0 + 3)
    sp.fill(HAZARD, 14, 15, 14, 15, H0, H0 + 3); sp.fill(HAZARD, 17, 18, 14, 15, H0, H0 + 3)
    door = sp.box_cells(28, 31, hy0, hy0 + 1, H0, H0 + 4, 'door')
    xc = sp.LX[16] + 20
    btn = sp.box_abs((xc - 12, sp.LY[20] - 8, (H0 + 1) * BS + 8), (xc + 12, sp.LY[20], (H0 + 1) * BS + 32), 'button')
    sp.ent('func_door', model=door, targetname='hangar_door', angles='-90 0 0', speed='80', wait='-1', lip='4')
    sp.ent('func_button', model=btn, target='hangar_door', spawnflags='1', wait='-1', speed='5')
    # ---- triggers
    t_hang = sp.box_cells(28, 31, 27, 28, H0, H0 + 4, 'aaatrigger')
    text(sp, 'txt_hangar', 'El cohete Lambda-7 espera en el centro del hangar.\nAbordalo para llegar a la estacion Meridiano.')
    sp.ent('trigger_once', model=t_hang, target='txt_hangar')
    t_end = sp.box_cells(28, 31, 30, 32, H0, H0 + 4, 'aaatrigger')
    sp.ent('trigger_changelevel', model=t_end, map='bm_dia2')
    t_annex = sp.box_cells(14, 18, 15, 16, H0, H0 + 3, 'aaatrigger')
    text(sp, 'txt_annex', 'Control del hangar. El boton rojo abre la compuerta principal.')
    sp.ent('trigger_once', model=t_annex, target='txt_annex')
    # ---- historia + jugador
    intro(sp, 'DIA 1  -  BLACK MESA\nLa cascada de resonancia aislo el complejo.\nUnica salida: el cohete del Hangar 7.')
    sp.ent('info_player_start', origin=sp.at(6, 6, 37), angles='0 45 0')
    for cls, i, j in (('weapon_crowbar', 8, 6), ('weapon_9mmhandgun', 8, 7), ('ammo_9mmclip', 9, 6), ('item_battery', 6, 9),
                      ('item_healthkit', 7, 9), ('item_suit', 5, 7)):
        sp.thing(cls, i, j)
    sp.thing('weapon_shotgun', 15, 18); sp.thing('ammo_buckshot', 16, 18); sp.thing('item_healthkit', 17, 17)
    sp.thing('weapon_9mmAR', 31, 26); sp.thing('ammo_9mmAR', 32, 26); sp.thing('ammo_ARgrenades', 31, 27)
    sp.thing('item_healthkit', 36, 28); sp.thing('item_battery', 22, 28); sp.thing('item_healthkit', 25, 38)
    # ---- enemigos
    for i, j in ((9, 12), (14, 10), (20, 6), (26, 14)): sp.mon('monster_headcrab', i, j, int(rng.integers(0, 360)))
    for i, j in ((16, 8), (24, 10), (22, 18)): sp.mon('monster_zombie', i, j, int(rng.integers(0, 360)))
    for i, j in ((26, 20), (30, 22), (34, 21), (22, 23)): sp.mon('monster_human_grunt', i, j, 270, weapons='3')
    for i, j in ((15, 17), (16, 18)): sp.mon('monster_human_grunt', i, j, 270, weapons='8')
    for i, j in ((24, 28), (34, 29), (25, 38), (34, 38), (29, 37)): sp.mon('monster_human_grunt', i, j, 270, weapons='3')
    for i, j in ((26, 31), (32, 30)): sp.mon('monster_zombie', i, j, int(rng.integers(0, 360)))
    sp.mon('monster_headcrab', 30, 28, 0)
    return sp, level_cfg(800)

# =========================================================================== DIA 2
def level2():
    NX = NY = 44; NZ = 12
    sp = Spec('bm_dia2', NX, NY, NZ, 'orbsky', (0.78, 0.86, 1.0))
    m = sp.mat; m[:] = PANEL
    rooms = {'R1': (4, 15, 4, 15), 'C1': (15, 22, 8, 11), 'R2': (22, 35, 4, 17), 'C2': (27, 30, 17, 25),
             'R3': (20, 39, 25, 38), 'C3': (11, 20, 29, 32), 'R4': (3, 10, 22, 40)}
    for (x0, x1, y0, y1) in rooms.values():
        sp.fill(AIR, x0, x1, y0, y1, 2, 7); sp.fill(STFLOOR, x0, x1, y0, y1, 1, 2)
        for i in range(x0, x1):
            for j in range(y0, y1):
                if i % 4 == 1 and j % 4 == 1: m[i, j, 7] = STLIGHT
    # ventanales al espacio (cielo con estrellas)
    sp.fill(SKY, 3, 4, 7, 12, 3, 6); sp.fill(SKY, 35, 36, 7, 14, 3, 6); sp.fill(SKY, 22, 36, 3, 4, 3, 6)
    sp.fill(SKY, 39, 40, 28, 35, 3, 6); sp.fill(SKY, 20, 39, 38, 39, 4, 6); sp.fill(SKY, 3, 10, 40, 41, 3, 6)
    # marcos de peligro en las entradas
    for (x0, x1, y0, y1) in ((14, 15, 8, 11), (21, 22, 8, 11), (27, 30, 16, 17), (27, 30, 24, 25), (19, 20, 29, 32)):
        sp.fill(HAZARD, x0, x1, y0, y1, 1, 2)
    # pilares y cajas
    for (px, py) in ((24, 29), (34, 29), (24, 34), (34, 34), (28, 9), (28, 13)): sp.fill(METAL, px, px + 2, py, py + 2, 2, 7)
    for (cx_, cy_, s) in ((6, 5, 2), (12, 6, 1), (6, 12, 2), (13, 13, 1), (25, 6, 2), (32, 15, 1), (4, 33, 1), (8, 25, 1)):
        sp.fill(CRATE, cx_, cx_ + s, cy_, cy_ + s, 2, 2 + s)
    # lanzadera en el hangar
    sp.fill(ROCKW, 5, 8, 30, 38, 2, 5); sp.fill(ROCKO, 5, 8, 33, 34, 2, 5); sp.fill(GLASS, 6, 7, 37, 38, 3, 4)
    sp.fill(ROCKO, 4, 5, 31, 35, 2, 3); sp.fill(ROCKO, 8, 9, 31, 35, 2, 3)
    # puerta + boton
    door = sp.box_cells(10, 11, 29, 32, 2, 7, 'door')
    sp.fill(AIR, 10, 11, 29, 32, 2, 7)
    xc = sp.LX[29] + 20
    btn = sp.box_abs((xc - 12, sp.LY[38] - 8, 3 * BS), (xc + 12, sp.LY[38], 3 * BS + 24), 'button')
    sp.ent('func_door', model=door, targetname='bay_door', angles='-90 0 0', speed='80', wait='-1', lip='4')
    sp.ent('func_button', model=btn, target='bay_door', spawnflags='1', wait='-1', speed='5')
    t_end = sp.box_cells(5, 8, 27, 29, 2, 6, 'aaatrigger')
    sp.ent('trigger_changelevel', model=t_end, map='bm_dia3')
    t1 = sp.box_cells(28, 29, 18, 19, 2, 6, 'aaatrigger'); t1x = sp.box_cells(27, 30, 18, 19, 2, 6, 'aaatrigger')
    text(sp, 'txt_lab', 'Algo de Xen viajo en el cohete.\nEl laboratorio de la estacion esta infestado.')
    sp.ent('trigger_once', model=t1x, target='txt_lab')
    t3 = sp.box_cells(28, 31, 26, 27, 2, 6, 'aaatrigger')
    text(sp, 'txt_reactor', 'Sala de control. Pulsa el boton del fondo para abrir la compuerta del hangar.')
    sp.ent('trigger_once', model=t3, target='txt_reactor')
    intro(sp, 'DIA 2  -  ESTACION MERIDIANO\nLlegas a la orbita. Las luces parpadean:\nalgo viajo contigo.')
    sp.ent('info_player_start', origin=sp.at(7, 8, 37), angles='0 0 0')
    for cls, i, j in (('weapon_crowbar', 6, 7), ('weapon_9mmhandgun', 6, 8), ('ammo_9mmclip', 7, 7), ('item_healthkit', 8, 9),
                      ('item_battery', 9, 8), ('weapon_shotgun', 12, 9), ('ammo_buckshot', 12, 10), ('weapon_9mmAR', 11, 5),
                      ('ammo_9mmAR', 11, 6)):
        sp.thing(cls, i, j)
    for i, j in ((24, 6), (31, 7), (26, 14), (33, 12)): sp.thing('item_healthkit' if i % 2 else 'item_battery', i, j)
    sp.thing('weapon_357', 33, 5); sp.thing('ammo_357', 33, 6); sp.thing('weapon_handgrenade', 30, 12); sp.thing('weapon_satchel', 24, 15)
    for i, j in ((22, 27), (36, 36), (24, 36)): sp.thing('item_healthkit', i, j)
    sp.thing('item_battery', 30, 30); sp.thing('ammo_9mmAR', 31, 27); sp.thing('weapon_crossbow', 36, 28); sp.thing('ammo_crossbow', 36, 29)
    for i, j in ((25, 10), (30, 8), (25, 14), (32, 6)): sp.mon('monster_houndeye', i, j, 180)
    for i, j in ((33, 14), (30, 15)): sp.mon('monster_alien_slave', i, j, 180)
    for i, j in ((28, 20), (28, 22), (29, 19)): sp.mon('monster_headcrab', i, j, 90)
    for i, j in ((24, 28), (36, 36), (33, 32)): sp.mon('monster_alien_slave', i, j, 270)
    sp.mon('monster_alien_grunt', 30, 36, 270); sp.mon('monster_houndeye', 22, 34, 0)
    for i, j in ((9, 36), (9, 35)): sp.mon('monster_alien_slave', i, j, 0)
    sp.mon('monster_houndeye', 4, 26, 0)
    return sp, level_cfg(600)

# =========================================================================== DIA 3
def level3():
    NX = NY = 50; NZ = 22; H0 = 5
    sp = Spec('bm_dia3', NX, NY, NZ, 'lunsky', (1.0, 1.0, 1.0))
    rng = np.random.default_rng(33)
    H = heightmap(NX, NY, 33, 4, 2, 10); H[3:17, 3:17] = H0
    cx_, cy_ = 25, 36
    def near_dome(i, j, r): return math.hypot(i - cx_, j - cy_) < r
    for i in range(NX):
        for j in range(NY):
            if near_dome(i, j, 16): H[i, j] = H0
    # cráteres
    for (ci, cj, r) in ((28, 14, 5), (40, 28, 4), (12, 26, 4), (42, 10, 4), (8, 44, 3), (44, 42, 3)):
        for i in range(NX):
            for j in range(NY):
                d = math.hypot(i - ci, j - cj)
                if d < r: H[i, j] = max(2, H0 - 2)
                elif d < r + 1: H[i, j] = H0 + 1
    for i in range(3, 17):
        for j in range(3, 17): H[i, j] = H0
    for (hx_, hy_) in ((20, 16), (36, 20), (10, 28)): H[hx_ - 2:hx_ + 8, hy_ - 3:hy_ + 8] = H0
    m = sp.mat
    for i in range(NX):
        for j in range(NY):
            for k in range(H[i, j]): m[i, j, k] = MOON if k >= H[i, j] - 2 else MOONROCK
    sp.sky_borders()
    for _ in range(12):
        i = int(rng.integers(3, NX - 3)); j = int(rng.integers(3, NY - 3))
        if near_dome(i, j, 15) or (3 <= i < 17 and 3 <= j < 17): continue
        for di in range(-1, 2):
            for dj in range(-1, 2):
                for k in range(H[i + di, j + dj], H[i + di, j + dj] + max(1, 3 - abs(di) - abs(dj))): m[i + di, j + dj, k] = MOONROCK
    # restos de la lanzadera
    for (i, j, hh, mt) in ((10, 8, 2, ROCKW), (11, 8, 2, ROCKO), (12, 8, 1, ROCKW), (10, 9, 1, ROCKW), (12, 9, 3, ROCKW),
                           (13, 9, 1, ROCKO), (11, 10, 2, ROCKW), (14, 10, 1, ROCKW)):
        sp.fill(mt, i, i + 1, j, j + 1, H0, H0 + hh)
    # ---- casetas
    def hut(x0, y0, gap_side='s'):
        sp.fill(DOMEW, x0, x0 + 6, y0, y0 + 6, H0, H0 + 4); sp.fill(AIR, x0 + 1, x0 + 5, y0 + 1, y0 + 5, H0, H0 + 3)
        sp.fill(LABF, x0 + 1, x0 + 5, y0 + 1, y0 + 5, H0 - 1, H0)
        sp.fill(AIR, x0 + 2, x0 + 4, y0, y0 + 1, H0, H0 + 3)
    hut(20, 16); hut(36, 20); hut(10, 28)
    # ---- cupula
    R_out, R_in = 9.6, 7.6
    for i in range(NX):
        for j in range(NY):
            for k in range(H0, NZ - 2):
                d2 = (i + .5 - cx_) ** 2 + (j + .5 - cy_) ** 2 + (k - H0 + .5) ** 2
                if d2 <= R_out ** 2: m[i, j, k] = DOMEW
                if d2 <= R_in ** 2: m[i, j, k] = AIR
    for i in range(NX):
        for j in range(NY):
            if (i + .5 - cx_) ** 2 + (j + .5 - cy_) ** 2 <= R_in ** 2: m[i, j, H0 - 1] = LABF
    sp.fill(AIR, 24, 27, 26, 31, H0, H0 + 4)                # tunel de entrada
    sp.fill(HAZARD, 23, 24, 27, 29, H0, H0 + 4); sp.fill(HAZARD, 27, 28, 27, 29, H0, H0 + 4)
    door = sp.box_cells(24, 27, 28, 29, H0, H0 + 4, 'door')
    # boton dentro de la caseta 3 (pared norte)
    xc = sp.LX[13] + 20
    btn = sp.box_abs((xc - 12, sp.LY[33] - 8, (H0 + 1) * BS + 8), (xc + 12, sp.LY[33], (H0 + 1) * BS + 32), 'button')
    sp.ent('func_door', model=door, targetname='dome_door', angles='-90 0 0', speed='80', wait='-1', lip='4')
    sp.ent('func_button', model=btn, target='dome_door', spawnflags='1', wait='-1', speed='5')
    # ---- historia / triggers
    intro(sp, 'DIA 3  -  LA LUNA\nLa base Selene emite la senal.\nEn su cupula central esta el origen de la invasion.')
    t_h = sp.box_cells(12, 14, 29, 30, H0, H0 + 3, 'aaatrigger')
    text(sp, 'txt_hut', 'Caseta de servicio. El boton abre la esclusa de la cupula.')
    sp.ent('trigger_once', model=t_h, target='txt_hut')
    t_d = sp.box_cells(24, 27, 25, 26, H0, H0 + 4, 'aaatrigger')
    text(sp, 'txt_dome', 'La esclusa esta sellada.\nBusca el boton en las casetas de servicio.')
    sp.ent('trigger_once', model=t_d, target='txt_dome')
    text(sp, 'fin_txt', 'La senal se apaga. La Tierra brilla en el horizonte.\nHas llegado mas lejos que nadie... y volveras a casa.\n\nFIN', y='0.3', hold='9')
    sp.ent('game_end', targetname='fin_end')
    sp.ent('multi_manager', targetname='boss_dead', fin_txt='0', fin_end='11')
    sp.ent('monster_gargantua', origin=sp.at(cx_, cy_, 40), angles='0 270 0', TriggerTarget='boss_dead', TriggerCondition='4')
    sp.mon('monster_alien_grunt', 22, 38, 270); sp.mon('monster_alien_grunt', 29, 38, 270)
    sp.ent('info_player_start', origin=sp.at(6, 6, 37), angles='0 45 0')
    for cls, i, j in (('weapon_crowbar', 8, 5), ('weapon_9mmhandgun', 8, 6), ('weapon_357', 9, 5), ('ammo_357', 9, 6),
                      ('ammo_9mmclip', 5, 8), ('item_healthkit', 6, 9), ('item_battery', 7, 9), ('item_suit', 5, 6)):
        sp.thing(cls, i, j)
    for (hx, hy, items) in ((22, 18, ('weapon_9mmAR', 'ammo_9mmAR', 'item_healthkit')), (38, 22, ('weapon_shotgun', 'ammo_buckshot', 'item_battery')),
                            (12, 30, ('weapon_rpg', 'ammo_rpgclip', 'item_healthkit'))):
        for q, cls in enumerate(items): sp.thing(cls, hx + q, hy + 2)
    sp.thing('weapon_gauss', 22, 41); sp.thing('ammo_gaussclip', 23, 41); sp.thing('item_healthkit', 28, 41)
    sp.thing('item_battery', 27, 42); sp.thing('weapon_egon', 24, 42); sp.thing('item_healthkit', 26, 33)
    sp.thing('weapon_handgrenade', 14, 20); sp.thing('weapon_satchel', 33, 14); sp.thing('item_healthkit', 30, 24)
    for i, j in ((20, 12), (31, 20), (36, 14)): sp.mon('monster_alien_grunt', i, j, 90)
    for i, j in ((14, 18), (24, 22), (33, 26), (44, 19)): sp.mon('monster_alien_slave', i, j, 90)
    for i, j in ((18, 12), (28, 24), (40, 16), (16, 24)): sp.mon('monster_houndeye', i, j, 90)
    sp.mon('monster_bullchicken', 22, 24, 90); sp.mon('monster_bullchicken', 34, 30, 90)
    return sp, level_cfg(160)

if __name__ == '__main__':
    cfgs = {}
    for fn in (level1, level2, level3):
        sp, cfg = fn(); build(sp); cfgs[sp.name] = cfg
    pickle.dump(cfgs, open('/home/claude/bm_cfgs.pkl', 'wb'))
